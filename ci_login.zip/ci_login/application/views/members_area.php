<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login System Dashboard</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css" />
	</head>
<body>
	<div id="container_login">
		<h1>Welcome Back ! <?php echo $name; ?></h1>
		<div id="body">
			<code class="succ"> Email Address : <?php echo $email; ?></code>
			<code class="succ"> Username : <?php echo $username; ?></code>
			<code class="succ"> <?php echo anchor('welcome/logout', 'Logout'); ?></code>
		</div>
	</div>
</body>
</html>