<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login System</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css" />
	</head>
<body>
	<div id="container_login">
		<h1>Error</h1>
		<div id="body">
			<code class="err"><?php echo $err_msg; ?></code>
			<code class="succ"><?php echo anchor('login', 'Login'); ?></code>
		</div>
	</div>
</body>
</html>