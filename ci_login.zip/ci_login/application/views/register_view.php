<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login System</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css" />
	</head>
<body>
	<div id="container_reg">
		<h1>Create An Account / Register </h1>
		<div id="body">
			<?php echo validation_errors('<p class="err">'); ?>
			
			<?php if(isset($err_msg)) : ?>
				<p class="err"> <?php echo $err_msg; ?></p>
			<?php endif; ?>
			
			<?php echo form_open("login/register",'id="form_register"'); ?>
			
			<code> Name : <?php echo form_input('txt_name', set_value('txt_name')); ?></code>
			<code> Email Address : <?php echo form_input('txt_email', set_value('txt_email')); ?></code>
			<code> Contact No : <?php echo form_input('txt_contact', set_value('txt_contact')); ?></code>
			<code> City : <?php echo form_input('txt_city', set_value('txt_city')); ?></code>

			<h1> Login info </h1>
			<code> Username : <?php echo form_input('txt_username', set_value('txt_username')); ?></code>
			<code> Password : <?php echo form_password('txt_password', set_value('txt_password')); ?></code>
			<code>
				Confirm Password : <?php echo form_password('txt_cpassword', set_value('txt_cpassword')); ?>
			</code>
			
			<?php echo form_submit('submit','Submit'); ?>
			<?php echo anchor('login', 'Login','class="create_link"'); ?>
			<?php echo form_close(); ?>
		</div>
	</div>
</body>
</html>