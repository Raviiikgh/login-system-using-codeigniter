<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login System</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css" />
	</head>
<body>
	<div id="container_login">
		<h1>Login</h1>
		<div id="body">
			<?php echo validation_errors('<p class="err">'); ?>
			
			<?php if(isset($err_msg)) : ?>
				<p class="err"> <?php echo $err_msg; ?></p>
			<?php endif; ?>
			
			<?php echo form_open("login/attempt",'id="form_login"'); ?>
			
			<code> Username : <?php echo form_input('txt_username', set_value('txt_username')); ?></code>
			<code> Password : <?php echo form_password('txt_password', set_value('txt_password')); ?></code>

			<?php echo form_submit('submit','Login'); ?>
			<?php echo anchor('login/signup', 'Create Account','class="create_link"'); ?>
			<?php echo form_close(); ?>
		</div>
	</div>
</body>
</html>