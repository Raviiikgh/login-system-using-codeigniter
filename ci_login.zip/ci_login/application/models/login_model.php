<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model{

	public function checkValidate(){
		
		$posted_data = array(
				'username' => $this->input->post('txt_username'),
				'password' => md5($this->input->post('txt_password'))
			);

		$sql = 'SELECT * FROM tbl_users WHERE username = ? AND password = ?';
		$q = $this->db->query($sql, $posted_data);
		
		if($q->num_rows() > 0){
			return $q->result();
		}else{
			return $data = 0;
		}
	}

	public function new_register(){
		
		$posted_data = array(
				'email' 	=> $this->input->post('txt_email'),
				'username' 	=> $this->input->post('txt_username')
			);

		$sql = 'SELECT * FROM tbl_users WHERE email = ? OR username = ?';
		$q = $this->db->query($sql, $posted_data);
		
		if($q->num_rows() > 0){
			
			return $data = 0;
		
		}else{
		
			$post_data = array(
				'name' 		=> $this->input->post('txt_name'),
				'username' 	=> $this->input->post('txt_username'),
				'email' 	=> $this->input->post('txt_email'),
				'password' 	=> md5($this->input->post('txt_password')),
				'contact_no'=> $this->input->post('txt_contact'),
				'city' 		=> $this->input->post('txt_city')
			);
			
			$insert = $this->db->insert('tbl_users', $post_data);
			
			if($insert){
				return $data = 1;
			}
		}
	}
}