<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index(){
		$this->load->view('login_view');
	}

	public function attempt(){
		$this->load->library('form_validation');

		$this->form_validation->set_rules('txt_username', 'Username', 'trim|required|max_length[8]');
		$this->form_validation->set_rules('txt_password', 'Password', 'trim|required');

		if($this->form_validation->run() == FALSE){
			$this->index();	
		}else{
			$this->load->model('login_model');
			$isCheck = $this->login_model->checkValidate();
			
			if($isCheck !== 0){
				$new_data = array(
					'id' => $isCheck[0]->id,
					'username' => $isCheck[0]->username,
					'name' => $isCheck[0]->name,
					'email' => $isCheck[0]->email,
					'is_logged' => TRUE
				);

				$this->session->set_userdata($new_data);
				redirect('welcome/dashboard');
			}else{
				$data['err_msg'] = 'Username or password is invalid.';
 				$this->load->view('login_view', $data);
			}
		}
	}

	public function signup(){
		$this->load->view('register_view');	
	}

	public function register(){
	
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('txt_name', 'Full Name', 'trim|required|max_length[20]');
		$this->form_validation->set_rules('txt_email', 'Email Address','trim|required|valid_email|max_length[50]');
		$this->form_validation->set_rules('txt_contact', 'Contact Number', 'trim|required|numeric|max_length[10]');
		$this->form_validation->set_rules('txt_city', 'City', 'trim|required|max_length[20]');
		$this->form_validation->set_rules('txt_username', 'Username', 'trim|required|max_length[8]|min_length[4]');
		$this->form_validation->set_rules('txt_password', 'Password', 'trim|required|max_length[8]|min_length[4]');
		$this->form_validation->set_rules('txt_cpassword', 'Confirm Password', 'trim|required|matches[txt_password]');

		if($this->form_validation->run() == FALSE){
			$this->signup();	
		}else{
			$this->load->model('login_model');
			$check_exists = $this->login_model->new_register(); 
			
			if($check_exists == 0) {
				$data['err_msg'] = 'Username / Email Adreess already exists, Please try another';
				$this->load->view('register_view',$data);	
			}else{
			
				redirect('login');
			}
		}
	}	

}