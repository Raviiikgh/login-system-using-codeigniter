<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->is_logged_in();
	}

	function is_logged_in(){
		
		$flag_on = $this->session->userdata('is_logged');
		
		if(isset($flag_on) && $flag_on == TRUE){
			$data['name'] = $this->session->userdata('name');
			$data['username'] = $this->session->userdata('username');
			$data['email'] = $this->session->userdata('email');
			$this->load->view('members_area', $data);		
		}else{
			$data['err_msg'] = 'You dont have permission to access this area';
			$this->load->view('warning_area', $data);
		}
	}


	public function dashboard(){

	}

	public function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}
}